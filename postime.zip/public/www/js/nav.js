const menuHtml = `<a href="create.html">메뉴</a>`;

const menuClass = document.querySelector(".menu");

menuClass.innerHTML = menuHtml;
