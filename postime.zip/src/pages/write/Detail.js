import React from "react";

const Detail = () => {
  return (
    <div>
      <h2>변경된 내용 출력</h2>
    </div>
  );
};

export default Detail;
