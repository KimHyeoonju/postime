const headerHtml = `
<header class="header">헤더</header>
`;

const headerClass = document.querySelector(".header");

headerClass.innerHTML = headerHtml;
